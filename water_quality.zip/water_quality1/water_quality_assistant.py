# water_quality_assistant.py
"""
GENERATIVE WATER QUALITY ASSISTANT (POE + ML)
CS5401 Mini Project - Water Quality / Potability
- Trains/loads water potability models (RandomForest + TensorFlow DNN)
- Uses Poe API to parse user queries and to generate human-readable recommendations
- CLI chat interface similar in style to the cattle example you provided
"""

import os
import re
import json
import time
import joblib
import warnings
import requests
import numpy as np
import pandas as pd
from typing import Dict, Any

warnings.filterwarnings("ignore")
np.random.seed(42)

# ML / DL
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.callbacks import EarlyStopping

print("💧 Generative Water Quality Assistant (Poe + ML)")
print("=" * 70)


# =========================================
# POE API CLIENT (simple requests-based)
# =========================================
class PoeAPIClient:
    """
    Minimal Poe API client using requests.
    - Requires POE_API_KEY environment variable or api_key passed in constructor.
    - Uses Chat Completions endpoint: POST https://api.poe.com/v1/chat/completions
    """
    def __init__(self, api_key: str = None, model: str = "Grok-4"):
        self.api_key = api_key or os.getenv("POE_API_KEY")
        self.model = model
        self.base_url = "https://api.poe.com/v1/chat/completions"
        if not self.api_key:
            print("⚠️ Warning: POE_API_KEY not found. Poe features will fallback to local behavior.")
        # A short system prompt to guide Poe when used
        self.system_prompt = (
            "You are a concise, practical water quality assistant for public health officers and "
            "environmental technicians. Produce clear, actionable, and non-prescriptive advice "
            "for water treatment and monitoring. When asked to extract parameters, respond in JSON only."
        )

    def query(self, user_message: str, max_tokens: int = 300, temperature: float = 0.3) -> str:
        """Send a chat completion request to Poe and return the assistant text."""
        if not self.api_key:
            return "⚠️ Poe API key missing; cannot call Poe. Please set POE_API_KEY environment variable."

        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": self.system_prompt},
                {"role": "user", "content": user_message}
            ],
            "temperature": temperature,
            "max_tokens": max_tokens
        }
        try:
            resp = requests.post(self.base_url, headers=headers, json=payload, timeout=20)
            resp.raise_for_status()
            data = resp.json()
            # safe retrieval of assistant text
            choice = data.get("choices", [{}])[0]
            msg = choice.get("message", {}).get("content", "")
            return msg.strip()
        except Exception as e:
            return f"⚠️ Poe API error: {e}"


# =========================================
# DATA LOADING & SYNTHETIC DATA (water)
# =========================================
def create_synthetic_water_dataset(n_samples: int = 1000) -> pd.DataFrame:
    """
    Create a synthetic water potability dataset with realistic ranges and a 'Potability' target.
    Features: ph, Hardness, Solids (TDS), Chloramines, Sulfate, Conductivity, Organic_carbon,
              Trihalomethanes, Turbidity
    """
    rng = np.random.RandomState(42)
    ph = rng.normal(7.0, 0.6, n_samples)  # typical 6.5-8.5
    hardness = rng.normal(150, 80, n_samples)  # mg/L
    solids = rng.normal(400, 300, n_samples)  # ppm
    chloramines = rng.normal(2.5, 1.2, n_samples)
    sulfate = rng.normal(120, 80, n_samples)
    conductivity = rng.normal(450, 300, n_samples)
    organic_carbon = rng.normal(4.0, 3.0, n_samples)
    trihalomethanes = rng.normal(50, 40, n_samples)
    turbidity = rng.exponential(2.0, n_samples)  # most small, some large

    df = pd.DataFrame({
        "ph": ph,
        "Hardness": np.clip(hardness, 0, None),
        "Solids": np.clip(solids, 0, None),
        "Chloramines": np.clip(chloramines, 0, None),
        "Sulfate": np.clip(sulfate, 0, None),
        "Conductivity": np.clip(conductivity, 0, None),
        "Organic_carbon": np.clip(organic_carbon, 0, None),
        "Trihalomethanes": np.clip(trihalomethanes, 0, None),
        "Turbidity": np.clip(turbidity, 0, None)
    })

    # Heuristic potability rule (for synthetic target)
    conditions_unpotable = (
        (df["ph"] < 6.5) | (df["ph"] > 8.5) |
        (df["Turbidity"] > 5) |
        (df["Organic_carbon"] > 8) |
        (df["Trihalomethanes"] > 100) |
        (df["Solids"] > 1000)
    )
    df["Potability"] = np.where(conditions_unpotable, 0, 1)
    return df


def load_water_data(path: str = None) -> pd.DataFrame:
    if path:
        try:
            df = pd.read_csv(path)
            print("✅ Loaded dataset from:", path)
            return df
        except Exception as e:
            print(f"❌ Failed to load dataset from {path}: {e}. Using synthetic dataset.")
    print("ℹ️ Using synthetic water dataset.")
    return create_synthetic_water_dataset()


# =========================================
# PREPROCESSOR
# =========================================
class WaterPreprocessor:
    def __init__(self):
        self.scaler = StandardScaler()
        self.feature_columns = ['ph','Hardness','Solids','Chloramines','Sulfate',
                                'Conductivity','Organic_carbon','Trihalomethanes','Turbidity']

    def fit_transform(self, df: pd.DataFrame):
        df = df.copy()
        # fill na with medians
        df[self.feature_columns] = df[self.feature_columns].fillna(df[self.feature_columns].median())
        X = df[self.feature_columns].values
        Xs = self.scaler.fit_transform(X)
        y = df["Potability"].values
        return Xs, y

    def transform_single(self, features: Dict[str, float]):
        # construct vector in fixed order and fill missing with 0 (or median fallback)
        vec = []
        for feat in self.feature_columns:
            if feat in features and features[feat] is not None:
                vec.append(float(features[feat]))
            else:
                vec.append(0.0)
        vec = np.array(vec).reshape(1, -1)
        return self.scaler.transform(vec)


# =========================================
# MODEL: RandomForest & NeuralNet TRAIN/LOAD
# =========================================
MODEL_DIR = "models"
os.makedirs(MODEL_DIR, exist_ok=True)
RF_PATH = os.path.join(MODEL_DIR, "rf_water_model.joblib")
DNN_PATH = os.path.join(MODEL_DIR, "dnn_water_model.h5")
SCALER_PATH = os.path.join(MODEL_DIR, "water_scaler.pkl")


def build_and_train_models(X, y):
    # Random Forest
    rf = RandomForestClassifier(n_estimators=150, random_state=42)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=42, stratify=y)
    rf.fit(X_train, y_train)
    acc_rf = accuracy_score(y_test, rf.predict(X_test))
    cv_rf = cross_val_score(rf, X, y, cv=4).mean()
    print(f"RandomForest: test_acc={acc_rf:.3f}, cv_mean={cv_rf:.3f}")

    # Save RF
    joblib.dump(rf, RF_PATH)

    # DNN (Keras)
    input_dim = X.shape[1]
    dnn = Sequential([
        Dense(64, activation="relu", input_dim=input_dim),
        Dropout(0.25),
        Dense(32, activation="relu"),
        Dropout(0.15),
        Dense(16, activation="relu"),
        Dense(1, activation="sigmoid")
    ])
    dnn.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])
    early = EarlyStopping(monitor="val_loss", patience=8, restore_best_weights=True)
    dnn.fit(X_train, y_train, validation_split=0.15, epochs=200, batch_size=32, callbacks=[early], verbose=0)
    loss, acc_dnn = dnn.evaluate(X_test, y_test, verbose=0)
    print(f"DNN: test_acc={acc_dnn:.3f}")
    dnn.save(DNN_PATH)

    return rf, dnn


def load_models_or_train(X=None, y=None):
    rf, dnn = None, None
    if os.path.exists(RF_PATH) and os.path.exists(DNN_PATH) and os.path.exists(SCALER_PATH):
        try:
            rf = joblib.load(RF_PATH)
            dnn = load_model(DNN_PATH)
            scaler = joblib.load(SCALER_PATH)
            # recompile DNN to avoid compile-not-built warnings
            dnn.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])
            print("✅ Loaded existing models and scaler.")
            return rf, dnn, scaler
        except Exception as e:
            print("⚠️ Failed to load existing models:", e)

    # fallback: train if X,y provided
    if X is not None and y is not None:
        print("ℹ️ Training new models...")
        rf, dnn = build_and_train_models(X, y)
        # Save scaler passed via preprocessor in caller
        return rf, dnn, None
    raise RuntimeError("No models available and no data to train on.")


# =========================================
# NLP: Extract parameters (Poe first, regex fallback)
# =========================================
def extract_parameters_with_poe(poe_client: PoeAPIClient, user_text: str) -> Dict[str, Any]:
    """
    Ask Poe to extract water parameters as JSON. If Poe unavailable or fails,
    fallback to regex extraction.
    """
    # Prompt instructing Poe to return JSON with all keys present (null if missing)
    prompt = (
        "Extract the following water parameters from the user text and return JSON only "
        "with keys: ph, Hardness, Solids, Chloramines, Sulfate, Conductivity, "
        "Organic_carbon, Trihalomethanes, Turbidity. If a parameter is missing, return null for that key.\n\n"
        f"User text: {user_text}\n\nReturn example: "
        '{"ph": 7.1, "Hardness": null, "Solids": 350, "Chloramines": null, "Sulfate": null, '
        '"Conductivity": null, "Organic_carbon": null, "Trihalomethanes": null, "Turbidity": 2}'
    )
    if poe_client and poe_client.api_key:
        resp = poe_client.query(prompt, max_tokens=200, temperature=0.0)
        # Try to parse JSON from the response
        try:
            # extract the first JSON object in the response
            json_text = re.search(r"\{.*\}", resp, flags=re.DOTALL)
            if json_text:
                data = json.loads(json_text.group(0))
                # ensure keys exist
                FEATURES = ['ph','Hardness','Solids','Chloramines','Sulfate','Conductivity','Organic_carbon','Trihalomethanes','Turbidity']
                parsed = {k: (float(data[k]) if data.get(k) is not None else None) if k in data else None for k in FEATURES}
                return parsed
        except Exception as e:
            # continue to fallback
            pass

    # REGEX FALLBACK: find numeric tokens after parameter names
    parsed = {k: None for k in ['ph','Hardness','Solids','Chloramines','Sulfate','Conductivity','Organic_carbon','Trihalomethanes','Turbidity']}
    for k in parsed.keys():
        pattern = rf"(?i){re.escape(k)}\s*[:=]?\s*([-+]?\d*\.?\d+)"
        m = re.search(pattern, user_text)
        if m:
            try:
                parsed[k] = float(m.group(1))
            except:
                parsed[k] = None
    # also try "ph 7.2" or "turbidity 3"
    simple_pairs = re.findall(r"([a-zA-Z_]+)\s*[:=]?\s*([-+]?\d*\.?\d+)", user_text)
    for kname, val in simple_pairs:
        key_lower = kname.strip().lower()
        for feat in parsed.keys():
            if feat.lower() == key_lower:
                try:
                    parsed[feat] = float(val)
                except:
                    pass
    return parsed


# =========================================
# ADVISOR CLASS: Predict and generate advice
# =========================================
class WaterQualityAdvisor:
    def __init__(self, rf_model, dnn_model, scaler, preprocessor: WaterPreprocessor, poe_client: PoeAPIClient):
        self.rf = rf_model
        self.dnn = dnn_model
        self.scaler = scaler
        self.preprocessor = preprocessor
        self.poe = poe_client
        self.feature_order = preprocessor.feature_columns

    def predict(self, features: Dict[str, float]) -> Dict[str, Any]:
        # build scaled input
        if self.scaler is None:
            # if no saved scaler, use preprocessor to transform
            x_scaled = self.preprocessor.transform_single(features)
        else:
            # build vector in same order, fill missing with medians (if available in scaler? no, fallback 0)
            x_scaled = self.preprocessor.transform_single(features)

        # predictions
        rf_prob = None
        dnn_prob = None
        try:
            if self.rf:
                rf_prob = max(self.rf.predict_proba(x_scaled)[0])
            if self.dnn:
                dnn_prob = float(self.dnn.predict(x_scaled)[0][0])
        except Exception:
            pass

        # fuse probabilities (simple average ignoring None)
        probs = [p for p in [rf_prob, dnn_prob] if p is not None]
        if len(probs) == 0:
            fused = 0.5
        else:
            fused = float(sum(probs) / len(probs))

        classification = "Drinkable" if fused >= 0.5 else "Not Drinkable"
        return {"probability": fused, "classification": classification, "rf_prob": rf_prob, "dnn_prob": dnn_prob}

    def explain_with_poe(self, features: Dict[str, Any], fused_prob: float) -> str:
        # Build a human context then call Poe to generate explanation if available
        context = {
            "features": features,
            "predicted_probability": round(float(fused_prob), 3)
        }
        prompt = (
            "You are a water quality expert assistant. Given the following features and the model "
            "probability that the water is drinkable, produce a concise explanation (2-6 sentences) "
            "stating whether the water is likely safe, why (which features contribute), and one practical "
            "recommendation for treatment or further testing. Use non-technical language for field staff.\n\n"
            f"Data:\n{json.dumps(context, indent=2)}\n\nRespond in plain text."
        )
        if self.poe and self.poe.api_key:
            return self.poe.query(prompt, max_tokens=250, temperature=0.2)
        # fallback rule-based explanation:
        expl_lines = []
        expl_lines.append(f"Model probability: {fused_prob:.2f} → { 'LIKELY SAFE' if fused_prob>=0.5 else 'LIKELY UNSAFE' }.")
        # simple heuristics
        if features.get("Turbidity") and features["Turbidity"] > 5:
            expl_lines.append(f"Turbidity is high ({features['Turbidity']} NTU), which suggests sediments or contamination.")
        if features.get("Organic_carbon") and features["Organic_carbon"] > 8:
            expl_lines.append("High organic carbon suggests organic pollution (sewage or surface runoff).")
        if features.get("Trihalomethanes") and features["Trihalomethanes"] > 80:
            expl_lines.append("Trihalomethanes are elevated (chemical by-products); consider treatment change.")
        expl_lines.append("Recommendation: prioritize local lab confirmatory tests; filtration and disinfection where appropriate.")
        return " ".join(expl_lines)


# =========================================
# CHATBOT (CLI)
# =========================================
class WaterQualityChatbot:
    def __init__(self, advisor: WaterQualityAdvisor, poe_client: PoeAPIClient):
        self.advisor = advisor
        self.poe = poe_client
        self.user_name = "User"
        self.location = "Unknown"

    def start(self):
        print("\n🤖 WATER QUALITY AI ASSISTANT (CLI)")
        self.user_name = input("Enter your name (or press Enter to remain anonymous): ").strip() or "User"
        self.location = input("Enter location / region: ").strip() or "Unknown"
        greeting = "Hello! I can analyze a water sample if you provide measurements, or answer general questions about water quality."
        if self.poe and self.poe.api_key:
            # ask Poe for a friendly greeting
            greet_prompt = f"Greet {self.user_name} from {self.location} warmly and ask how you can assist with water quality."
            r = self.poe.query(greet_prompt, max_tokens=80, temperature=0.6)
            if r and "⚠️" not in r:
                greeting = r
        print(f"\n🤖 {greeting}\n")
        print("Type 'quit' to exit, 'sample' to input a sample manually, or ask a question in natural language.\n")

        while True:
            user_input = input(f"{self.user_name}: ").strip()
            if not user_input:
                continue
            if user_input.lower() in ["quit", "exit"]:
                farewell = "Goodbye and stay safe with your water monitoring."
                if self.poe and self.poe.api_key:
                    farewell = self.poe.query(f"Say a warm goodbye to {self.user_name} from {self.location}.", max_tokens=40)
                print("\n🤖", farewell)
                break
            elif user_input.lower().startswith("sample"):
                # run a sample flow
                print("\nEnter sample values (press Enter to use default/median):")
                sample = {}
                for feat in self.advisor.feature_order:
                    val = input(f" - {feat}: ").strip()
                    sample[feat] = float(val) if val != "" else None
                result = self.run_sample(sample)
                print("\n" + result + "\n")
            elif "check" in user_input.lower() and "water" in user_input.lower():
                # user likely wants to check: ask for params inline or direct to sample
                print("You can type the sample inline (e.g., 'ph 7.2 turbidity 3') or type 'sample' to enter interactively.")
            else:
                # try to parse numbers via Poe then predict
                parsed = extract_parameters_with_poe(self.poe, user_input)
                if all(v is None for v in parsed.values()):
                    # maybe the user asked a general question -> forward to Poe for general answer
                    if self.poe and self.poe.api_key:
                        resp = self.poe.query(user_input, max_tokens=220, temperature=0.5)
                        print("\n🤖", resp, "\n")
                    else:
                        print("\n🤖 I couldn't detect sample parameters in your message. Please provide numbers (ph, Turbidity, etc.) or type 'sample'.\n")
                else:
                    res = self.run_sample(parsed)
                    print("\n" + res + "\n")

    def run_sample(self, parsed_features: Dict[str, Any]) -> str:
        # Replace None with medians from training dataset if possible (we used scaler saved earlier)
        # We'll use the preprocessor median fallback: load training data if exists
        data_path = None  # not stored in this object; rely on preprocessor to handle missing via zeros
        # get prediction
        try:
            pred = self.advisor.predict(parsed_features)
            explanation = self.advisor.explain_with_poe(parsed_features, pred["probability"])
            out = f"Prediction: {pred['classification']} (prob={pred['probability']:.3f})\n"
            out += "Details:\n"
            for k, v in parsed_features.items():
                out += f" - {k}: {v}\n"
            out += "\nExplanation & recommendation:\n" + explanation
            return out
        except Exception as e:
            return f"Error running sample prediction: {e}"


# =========================================
# MAIN: load data, preprocess, train/load models, start chatbot
# =========================================
def main(data_file: str = None):
    # 1) load data
    df = load_water_data(data_file)

    # 2) preprocessor fit/transform and save scaler
    preproc = WaterPreprocessor()
    Xs, y = preproc.fit_transform(df)
    joblib.dump(preproc.scaler, SCALER_PATH)

    # 3) load or train models (RF + DNN)
    try:
        rf, dnn, scaler_loaded = load_models_or_train(X=Xs, y=y)
        # if scaler_loaded is None (we just trained), load the scaler we just saved
        if scaler_loaded is None:
            scaler_loaded = joblib.load(SCALER_PATH)
    except Exception as e:
        print("Training/loading models failed:", e)
        return

    # 4) instantiate Poe client
    poe_client = PoeAPIClient(api_key=os.getenv("POE_API_KEY"), model="gpt-3.5-turbo")

    # 5) advisor + chatbot
    advisor = WaterQualityAdvisor(rf, dnn, scaler_loaded, preproc, poe_client)
    chatbot = WaterQualityChatbot(advisor, poe_client)

    # 6) optional model evaluation display (console)
    # Quick evaluation on a held-out split
    X_train, X_test, y_train, y_test = train_test_split(Xs, y, test_size=0.25, random_state=42, stratify=y)
    ypred = rf.predict(X_test)
    print("\nRandomForest Evaluation (on hold-out):")
    print("Accuracy:", accuracy_score(y_test, ypred))
    print(classification_report(y_test, ypred))
    cm = confusion_matrix(y_test, ypred)
    print("Confusion matrix:\n", cm)

    # 7) start CLI chatbot
    chatbot.start()


if __name__ == "__main__":
    # Replace None with path to your CSV if you have local dataset
    # Example: main("data/water_potability.csv")
    main("data/water_potability.csv")
