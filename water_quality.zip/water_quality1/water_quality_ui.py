# water_quality_ui.py
import os
import gradio as gr
from io import BytesIO
from PIL import Image
import matplotlib.pyplot as plt
import joblib
from tensorflow.keras.models import load_model

# Import your backend
from water_quality_assistant import (
    PoeAPIClient,
    WaterPreprocessor,
    WaterQualityAdvisor,
    extract_parameters_with_poe,
    load_models_or_train,
    load_water_data,
    SCALER_PATH,
    MODEL_DIR
)

# Initialization
os.makedirs("data", exist_ok=True)
os.makedirs(MODEL_DIR, exist_ok=True)

df = load_water_data("data/water_potability.csv")
preproc = WaterPreprocessor()
Xs, y = preproc.fit_transform(df)
rf, dnn, scaler_loaded = load_models_or_train(Xs, y)
if scaler_loaded is None:
    scaler_loaded = joblib.load(SCALER_PATH)

poe_client = PoeAPIClient(api_key=os.getenv("POE_API_KEY"), model="gpt-3.5-turbo")
advisor = WaterQualityAdvisor(rf, dnn, scaler_loaded, preproc, poe_client)

# Helper to plot probability bars
def plot_probabilities(rf_prob, dnn_prob, fused_prob):
    labels = ["RF", "DNN", "Fused"]
    values = [rf_prob or 0, dnn_prob or 0, fused_prob]
    colors = ["#008080", "#4682B4", "#32CD32"]
    fig, ax = plt.subplots(figsize=(5, 3))
    ax.barh(labels, values, color=colors)
    ax.set_xlim(0, 1)
    ax.set_xlabel("Probability")
    for i, v in enumerate(values):
        ax.text(v + 0.02, i, f"{v:.2f}", va="center")
    plt.tight_layout()
    buf = BytesIO()
    plt.savefig(buf, format="png", dpi=100)
    plt.close(fig)
    buf.seek(0)
    return Image.open(buf)

# Core prediction functions
def analyze_text(user_text):
    parsed = extract_parameters_with_poe(poe_client, user_text)
    if all(v is None for v in parsed.values()):
        if poe_client.api_key:
            return poe_client.query(user_text), None
        else:
            return "⚠️ Please include some numeric values (like pH, Turbidity) or use manual input.", None
    result = advisor.predict(parsed)
    explanation = advisor.explain_with_poe(parsed, result["probability"])
    chart = plot_probabilities(result["rf_prob"], result["dnn_prob"], result["probability"])
    md = f"**Prediction:** {result['classification']}  \n**Confidence:** {result['probability']:.2f}\n\n"
    md += "**Sample Values:**  \n"
    for k, v in parsed.items():
        md += f"- {k}: {v}  \n"
    md += "\n**Explanation:**\n" + explanation
    return md, chart

def analyze_manual(ph, Hardness, Solids, Chloramines, Sulfate, Conductivity, Organic_carbon, Trihalomethanes, Turbidity):
    features = { "ph": ph, "Hardness": Hardness, "Solids": Solids, "Chloramines": Chloramines,
                 "Sulfate": Sulfate, "Conductivity": Conductivity, "Organic_carbon": Organic_carbon,
                 "Trihalomethanes": Trihalomethanes, "Turbidity": Turbidity }
    result = advisor.predict(features)
    explanation = advisor.explain_with_poe(features, result["probability"])
    chart = plot_probabilities(result["rf_prob"], result["dnn_prob"], result["probability"])
    md = f"**Prediction:** {result['classification']}  \n**Confidence:** {result['probability']:.2f}\n\n"
    md += "**Input Features:**  \n"
    for k, v in features.items():
        md += f"- {k}: {v}  \n"
    md += "\n**Explanation:**\n" + explanation
    return md, chart

# Custom CSS with background image
custom_css = f"""
body {{
    background-image: url("data/sea water.jpg");
    background-size: cover;
    background-position: center;
    color: #005b99;
}}
.gradio-container {{
    background-color: rgba(255, 255, 255, 0.85);
    border-radius: 12px;
    padding: 20px;
}}
h1, h2, h3 {{
    color: #005b99;
}}
"""

intro_md = """
# 💧 Generative Water Quality Assistant  
Use ML + Generative AI to assess if water is drinkable, with explanations.
"""

nl_tab = gr.Interface(
    fn=analyze_text,
    inputs=gr.Textbox(lines=3, placeholder="e.g., 'ph 7.2, turbidity 3'"),
    outputs=[gr.Markdown(), gr.Image()],
    title="🧠 Natural Input",
    theme="default"
)

manual_tab = gr.Interface(
    fn=analyze_manual,
    inputs=[
        gr.Number(label="pH", value=7.0),
        gr.Number(label="Hardness (mg/L)", value=150),
        gr.Number(label="Solids (ppm)", value=300),
        gr.Number(label="Chloramines (mg/L)", value=2.5),
        gr.Number(label="Sulfate (mg/L)", value=120),
        gr.Number(label="Conductivity (µS/cm)", value=450),
        gr.Number(label="Organic Carbon (mg/L)", value=4.0),
        gr.Number(label="Trihalomethanes (µg/L)", value=50),
        gr.Number(label="Turbidity (NTU)", value=2.0)
    ],
    outputs=[gr.Markdown(), gr.Image()],
    title="🧪 Manual Input",
    theme="default"
)

app = gr.TabbedInterface([nl_tab, manual_tab], ["Natural", "Manual"], css=custom_css, title="Water Quality AI")

if __name__ == "__main__":
    app.launch()
