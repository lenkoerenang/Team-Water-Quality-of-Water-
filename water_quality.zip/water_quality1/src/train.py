# src/train.py
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
import joblib
import matplotlib.pyplot as plt
import os

# paths
DATA_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data', 'water_potability.csv')
MODEL_PATH = os.path.join(os.path.dirname(__file__), 'water_rf.joblib')
FIG_PATH = os.path.join(os.path.dirname(__file__), 'feature_importance.png')

def load_and_clean(path=DATA_PATH):
    df = pd.read_csv(path)
    # fill missing values with medians
    df = df.fillna(df.median(numeric_only=True))
    return df

def train_and_save(df):
    X = df.drop('Potability', axis=1)
    y = df['Potability']
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )

    model = RandomForestClassifier(n_estimators=200, random_state=42)
    model.fit(X_train, y_train)

    # predictions
    y_pred = model.predict(X_test)
    acc = accuracy_score(y_test, y_pred)
    print(f"Test accuracy: {acc:.4f}")
    print(classification_report(y_test, y_pred))

    # confusion matrix
    cm = confusion_matrix(y_test, y_pred)
    print("Confusion matrix:\\n", cm)

    # feature importance plot
    importances = pd.Series(model.feature_importances_, index=X.columns).sort_values(ascending=True)
    plt.figure(figsize=(7,5))
    importances.plot(kind='barh')
    plt.title('Feature importance')
    plt.tight_layout()
    plt.savefig(FIG_PATH)
    print("Saved feature importance to", FIG_PATH)

    # save model
    joblib.dump(model, MODEL_PATH)
    print("Saved model to", MODEL_PATH)

    return model, X_test, y_test

def predict_sample(model):
    # example sample, adapt values as you need
    sample = pd.DataFrame([{
        'ph': 7.2,
        'Hardness': 200,
        'Solids': 15000,
        'Chloramines': 6.5,
        'Sulfate': 320,
        'Conductivity': 400,
        'Organic_carbon': 10,
        'Trihalomethanes': 60 if 'Trihalomethanes' in model.feature_names_in_ else 60,
        'Turbidity': 3
    }])
    # keep only trained features (some datasets may lack Trihalomethanes column)
    features = model.feature_names_in_
    sample = sample[features]
    pred = model.predict(sample)[0]
    prob = model.predict_proba(sample)[0][1]
    print(f"Sample predicted: {'Drinkable' if pred==1 else 'Not Drinkable'} (prob={prob:.3f})")

if __name__ == '__main__':
    df = load_and_clean()
    model, X_test, y_test = train_and_save(df)
    predict_sample(model)
